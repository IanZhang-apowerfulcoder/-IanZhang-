---
name: Stage Task
about: 阶段任务
---

Task ID:
Owner:
Stage:
Goal:
Dependencies:
Contracts:
Acceptance:
