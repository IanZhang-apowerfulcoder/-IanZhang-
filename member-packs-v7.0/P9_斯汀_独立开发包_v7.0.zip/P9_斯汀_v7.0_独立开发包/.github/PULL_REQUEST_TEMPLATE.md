## 任务卡

- Task ID:
- Owner:
- Reviewers:

## 修改范围

## 不修改范围

## 契约版本

## 测试和证据

- [ ] `python scripts/validate_v7_contracts.py`
- [ ] 单元/集成测试
- [ ] 接口样例或截图/录屏
- [ ] 验收标准逐项自检
- [ ] 回滚方案
