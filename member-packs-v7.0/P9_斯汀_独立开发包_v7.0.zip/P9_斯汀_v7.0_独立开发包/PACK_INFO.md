# P9 斯汀 独立开发包 v7.0

## 长期角色

平行审核 Agent、独立 Evals、质量门禁、发布与比赛材料

## 使用顺序

1. 阅读 `README.md`；
2. 阅读 `members/P9_斯汀/00_开始这里.md`；
3. 阅读 `members/P9_斯汀/00_完整开发文件.md`；
4. 只领取当前阶段任务卡；
5. 以 API、Schema、数据库和任务卡为事实标准；
6. 提交 PR、测试日志、接口样例、已知限制和回滚方案。

## 专项设计文件

- `docs/14_测试与验收标准.md`
- `docs/16_任务卡与PR规则.md`
- `docs/18_演示与评测指标.md`
- `docs/20_开发启动清单.md`
- `docs/36_平行Agent生产与审核架构.md`
- `docs/40_比赛提交映射与最终交付清单.md`

## 必须遵守的契约

- `contracts/jsonschema/agents/factuality_review_output.schema.json`
- `contracts/jsonschema/agents/difficulty_review_output.schema.json`
- `contracts/jsonschema/agents/assessment_review_output.schema.json`
- `contracts/jsonschema/agents/safety_review_output.schema.json`
- `contracts/jsonschema/agents/review_output.schema.json`
- `reports/final_validation_report.md`

## 八阶段任务

- `tasks/S0/P9.md`
- `tasks/S1/P9.md`
- `tasks/S2/P9.md`
- `tasks/S3/P9.md`
- `tasks/S4/P9.md`
- `tasks/S5/P9.md`
- `tasks/S6/P9.md`
- `tasks/S7/P9.md`

## 主要复核人

P1、P2、P3、P7

## 禁止事项

- 不得自行增加、删除或重连核心 Agent；
- 不得绕过后端直接写权威数据库；
- 不得私自改变冻结字段或接口；
- 不得把 Mock、规划或未验证指标当成最终成果。
