# P5 郑翘楚 独立开发包 v7.0

## 长期角色

业务后端、Public API、权限、业务状态机与集成适配

## 使用顺序

1. 阅读 `README.md`；
2. 阅读 `members/P5_郑翘楚/00_开始这里.md`；
3. 阅读 `members/P5_郑翘楚/00_完整开发文件.md`；
4. 只领取当前阶段任务卡；
5. 以 API、Schema、数据库和任务卡为事实标准；
6. 提交 PR、测试日志、接口样例、已知限制和回滚方案。

## 专项设计文件

- `docs/06_系统模块边界.md`
- `docs/09_数据流与调用链.md`
- `docs/10_命名与字段契约.md`
- `docs/11_接口所有权与变更流程.md`
- `docs/13_数据库与持久化约束.md`

## 必须遵守的契约

- `api/openapi.yaml`
- `api/internal_openapi.yaml`
- `api/field_dictionary.yaml`
- `api/error_codes.yaml`
- `database/schema.sql`

## 八阶段任务

- `tasks/S0/P5.md`
- `tasks/S1/P5.md`
- `tasks/S2/P5.md`
- `tasks/S3/P5.md`
- `tasks/S4/P5.md`
- `tasks/S5/P5.md`
- `tasks/S6/P5.md`
- `tasks/S7/P5.md`

## 主要复核人

P1、P2、P6、P9

## 禁止事项

- 不得自行增加、删除或重连核心 Agent；
- 不得绕过后端直接写权威数据库；
- 不得私自改变冻结字段或接口；
- 不得把 Mock、规划或未验证指标当成最终成果。
