# P7 陈严谨 独立开发包 v7.0

## 长期角色

知识库持续维护、检索执行器、Evidence Fusion 与 RAG 评测

## 使用顺序

1. 阅读 `README.md`；
2. 阅读 `members/P7_陈严谨/00_开始这里.md`；
3. 阅读 `members/P7_陈严谨/00_完整开发文件.md`；
4. 只领取当前阶段任务卡；
5. 以 API、Schema、数据库和任务卡为事实标准；
6. 提交 PR、测试日志、接口样例、已知限制和回滚方案。

## 专项设计文件

- `docs/32_预建专业知识库主线修订.md`
- `docs/33_企业级RAG知识库接入与验收.md`
- `docs/34_知识库交付清单与团队接入.md`
- `docs/35_自适应多策略RAG与路由Agent.md`
- `docs/37_知识库持续维护与版本发布.md`

## 必须遵守的契约

- `api/knowledge_domain_api.yaml`
- `api/internal_openapi.yaml`
- `contracts/jsonschema/services/retrieval_request.schema.json`
- `contracts/jsonschema/services/retrieval_plan.schema.json`
- `contracts/jsonschema/services/evidence_bundle.schema.json`
- `knowledge-bases/enterprise-rag-engineering-v2/contracts/knowledge-api.yaml`

## 八阶段任务

- `tasks/S0/P7.md`
- `tasks/S1/P7.md`
- `tasks/S2/P7.md`
- `tasks/S3/P7.md`
- `tasks/S4/P7.md`
- `tasks/S5/P7.md`
- `tasks/S6/P7.md`
- `tasks/S7/P7.md`

## 主要复核人

P1、P2、P6、P9

## 禁止事项

- 不得自行增加、删除或重连核心 Agent；
- 不得绕过后端直接写权威数据库；
- 不得私自改变冻结字段或接口；
- 不得把 Mock、规划或未验证指标当成最终成果。
