# P2 李佳乐 独立开发包 v7.0

## 长期角色

Agent Runtime、RAG Router Agent、并行调度与仲裁实现

## 使用顺序

1. 阅读 `README.md`；
2. 阅读 `members/P2_李佳乐/00_开始这里.md`；
3. 阅读 `members/P2_李佳乐/00_完整开发文件.md`；
4. 只领取当前阶段任务卡；
5. 以 API、Schema、数据库和任务卡为事实标准；
6. 提交 PR、测试日志、接口样例、已知限制和回滚方案。

## 专项设计文件

- `docs/07_七核心智能体与平行Agent职责.md`
- `docs/08_联合决策状态机.md`
- `docs/15_AI辅助开发约束.md`
- `docs/35_自适应多策略RAG与路由Agent.md`
- `docs/36_平行Agent生产与审核架构.md`
- `docs/38_RetrievalTrace与Event事件规范.md`

## 必须遵守的契约

- `api/internal_openapi.yaml`
- `api/internal_agent_interfaces.yaml`
- `contracts/jsonschema/agents/rag_router_input.schema.json`
- `contracts/jsonschema/agents/rag_router_output.schema.json`
- `contracts/jsonschema/agents/arbitration_input.schema.json`
- `contracts/jsonschema/agents/arbitration_output.schema.json`
- `contracts/jsonschema/services/retrieval_plan.schema.json`
- `contracts/jsonschema/services/workflow_event.schema.json`

## 八阶段任务

- `tasks/S0/P2.md`
- `tasks/S1/P2.md`
- `tasks/S2/P2.md`
- `tasks/S3/P2.md`
- `tasks/S4/P2.md`
- `tasks/S5/P2.md`
- `tasks/S6/P2.md`
- `tasks/S7/P2.md`

## 主要复核人

P1、P5、P7、P9

## 禁止事项

- 不得自行增加、删除或重连核心 Agent；
- 不得绕过后端直接写权威数据库；
- 不得私自改变冻结字段或接口；
- 不得把 Mock、规划或未验证指标当成最终成果。
