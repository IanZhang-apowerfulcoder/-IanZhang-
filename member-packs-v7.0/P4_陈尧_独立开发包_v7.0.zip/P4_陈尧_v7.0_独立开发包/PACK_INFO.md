# P4 陈尧 独立开发包 v7.0

## 长期角色

全站前端、用户体验、Agent/RAG 可观测性与数据可视化

## 使用顺序

1. 阅读 `README.md`；
2. 阅读 `members/P4_陈尧/00_开始这里.md`；
3. 阅读 `members/P4_陈尧/00_完整开发文件.md`；
4. 只领取当前阶段任务卡；
5. 以 API、Schema、数据库和任务卡为事实标准；
6. 提交 PR、测试日志、接口样例、已知限制和回滚方案。

## 专项设计文件

- `docs/12_前端页面接口依赖.md`
- `docs/18_演示与评测指标.md`
- `docs/21_端到端用户流程与接口审计.md`
- `docs/38_RetrievalTrace与Event事件规范.md`

## 必须遵守的契约

- `api/openapi.yaml`
- `contracts/typescript/contracts.ts`
- `contracts/jsonschema/services/workflow_event.schema.json`
- `contracts/jsonschema/services/retrieval_trace.schema.json`

## 八阶段任务

- `tasks/S0/P4.md`
- `tasks/S1/P4.md`
- `tasks/S2/P4.md`
- `tasks/S3/P4.md`
- `tasks/S4/P4.md`
- `tasks/S5/P4.md`
- `tasks/S6/P4.md`
- `tasks/S7/P4.md`

## 主要复核人

P1、P5、P9

## 禁止事项

- 不得自行增加、删除或重连核心 Agent；
- 不得绕过后端直接写权威数据库；
- 不得私自改变冻结字段或接口；
- 不得把 Mock、规划或未验证指标当成最终成果。
