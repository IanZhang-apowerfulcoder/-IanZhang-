# P3 杨欣怡 独立开发包 v7.0

## 长期角色

诊断、学习路径、测评评价与学习者画像

## 使用顺序

1. 阅读 `README.md`；
2. 阅读 `members/P3_杨欣怡/00_开始这里.md`；
3. 阅读 `members/P3_杨欣怡/00_完整开发文件.md`；
4. 只领取当前阶段任务卡；
5. 以 API、Schema、数据库和任务卡为事实标准；
6. 提交 PR、测试日志、接口样例、已知限制和回滚方案。

## 专项设计文件

- `docs/07_七核心智能体与平行Agent职责.md`
- `docs/09_数据流与调用链.md`
- `docs/13_数据库与持久化约束.md`
- `docs/14_测试与验收标准.md`
- `docs/36_平行Agent生产与审核架构.md`

## 必须遵守的契约

- `contracts/jsonschema/agents/diagnosis_input.schema.json`
- `contracts/jsonschema/agents/diagnosis_output.schema.json`
- `contracts/jsonschema/agents/path_plan_input.schema.json`
- `contracts/jsonschema/agents/path_plan_output.schema.json`
- `contracts/jsonschema/agents/assessment_input.schema.json`
- `contracts/jsonschema/agents/assessment_output.schema.json`
- `contracts/jsonschema/agents/difficulty_review_output.schema.json`

## 八阶段任务

- `tasks/S0/P3.md`
- `tasks/S1/P3.md`
- `tasks/S2/P3.md`
- `tasks/S3/P3.md`
- `tasks/S4/P3.md`
- `tasks/S5/P3.md`
- `tasks/S6/P3.md`
- `tasks/S7/P3.md`

## 主要复核人

P1、P5、P9

## 禁止事项

- 不得自行增加、删除或重连核心 Agent；
- 不得绕过后端直接写权威数据库；
- 不得私自改变冻结字段或接口；
- 不得把 Mock、规划或未验证指标当成最终成果。
