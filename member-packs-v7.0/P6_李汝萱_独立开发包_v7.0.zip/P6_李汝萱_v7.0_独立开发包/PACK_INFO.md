# P6 李汝萱 独立开发包 v7.0

## 长期角色

数据库、版本、Event Store、Trace 与指标数据平台

## 使用顺序

1. 阅读 `README.md`；
2. 阅读 `members/P6_李汝萱/00_开始这里.md`；
3. 阅读 `members/P6_李汝萱/00_完整开发文件.md`；
4. 只领取当前阶段任务卡；
5. 以 API、Schema、数据库和任务卡为事实标准；
6. 提交 PR、测试日志、接口样例、已知限制和回滚方案。

## 专项设计文件

- `docs/13_数据库与持久化约束.md`
- `docs/23_标识符与关联键生命周期.md`
- `docs/25_异步任务轮询与状态规则.md`
- `docs/38_RetrievalTrace与Event事件规范.md`

## 必须遵守的契约

- `database/schema.sql`
- `database/migrations/007_adaptive_parallel_rag.sql`
- `api/field_dictionary.yaml`
- `contracts/jsonschema/services/workflow_event.schema.json`
- `contracts/jsonschema/services/retrieval_trace.schema.json`

## 八阶段任务

- `tasks/S0/P6.md`
- `tasks/S1/P6.md`
- `tasks/S2/P6.md`
- `tasks/S3/P6.md`
- `tasks/S4/P6.md`
- `tasks/S5/P6.md`
- `tasks/S6/P6.md`
- `tasks/S7/P6.md`

## 主要复核人

P1、P5、P9

## 禁止事项

- 不得自行增加、删除或重连核心 Agent；
- 不得绕过后端直接写权威数据库；
- 不得私自改变冻结字段或接口；
- 不得把 Mock、规划或未验证指标当成最终成果。
